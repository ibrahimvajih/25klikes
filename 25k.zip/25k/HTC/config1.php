<?php
$dataLog  =  array(
'email' => 'Facebook Email',
'pass' => 'Facebook Password',
'apps' => 'Enter App ID',# App ID
);

?>