Auto Like VIP 30K 

Developer : Faishal
Facebook : www.facebook.com/InfinteException
Script Language : PHP
Updated On : 24 August, 2016
Price : $50


Copyright Details : Please don't edit, sell or modify basic codes without permission.




Script Requirements
VPS, cPanel installed, support Cron Jobs



How To Install

1) Upload the script on server in any directory
2) Edit Config.php, Config2.php 
Open Nokia & HTC and Edit Config1.php
3) CHMOD Faishal.txt 777
4) Setup Cron Jobs command in panel
Run cron.php, cron1.php, cron2.php, cron3.php, Nokia/refresh.php, HTC/refresh.php in every 1 Min.
5) Done


Profile Setup
Allow Nokia & HTC to access your Facebook Account
Enable Followers, Post Must Be In Public




Script Features


Auto Fetch New Post

No Maintaince Required Once Successfully Installed

Continuous Sending Likes 

Fast Likes


For any details or query feel free to contact us
www.facebook.com/InfinteException
