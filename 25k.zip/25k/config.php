<?php
$developer= 'Faishal'; // www.Facebook.com/InfiniteException
$domain= 'http://webscripted.com'; // Full Installation Path
$linktoken= 'http://webscripted.com/HTC/token.txt'; // Token Htc
$id_like= '100011666252922'; // ID User VIP
$limitlike= '1000000'; // Limit
?>