<?php
$developer= 'Faishal'; // www.facebook.com/InfiniteException
$domain= 'http://webscripted.com'; // Full Installation Path
$linktoken= 'http://webscripted.com/Nokia/token.txt'; // Token Nokia
$id_like= '100011666252922'; // ID User VIP
$limitlike= '1000000'; // Limit
?>