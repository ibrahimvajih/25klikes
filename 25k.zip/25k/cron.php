<?php
include 'config.php';
fshl(''.$domain.'/1.php');
fshl(''.$domain.'/2.php');
fshl(''.$domain.'/3.php');
fshl(''.$domain.'/4.php');
fshl(''.$domain.'/5.php');
fshl(''.$domain.'/6.php');
fshl(''.$domain.'/7.php');
fshl(''.$domain.'/8.php');
fshl(''.$domain.'/9.php');
fshl(''.$domain.'/10.php');
function fshl($url){
   $curl = curl_init();
   curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
   curl_setopt($curl, CURLOPT_URL, $url);
   $ch = curl_exec($curl);
   curl_close($curl);
   return $ch;
   }
?>