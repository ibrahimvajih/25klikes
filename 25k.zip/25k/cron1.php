<?php
include 'config.php';
fshl(''.$domain.'/11.php');
fshl(''.$domain.'/12.php');
fshl(''.$domain.'/13.php');
fshl(''.$domain.'/14.php');
fshl(''.$domain.'/15.php');
fshl(''.$domain.'/16.php');
fshl(''.$domain.'/17.php');
fshl(''.$domain.'/18.php');
fshl(''.$domain.'/19.php');
function fshl($url){
   $curl = curl_init();
   curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
   curl_setopt($curl, CURLOPT_URL, $url);
   $ch = curl_exec($curl);
   curl_close($curl);
   return $ch;
   }
?>