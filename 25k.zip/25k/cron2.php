<?php
include 'config.php';
fshl(''.$domain.'/20.php');
fshl(''.$domain.'/21.php');
fshl(''.$domain.'/22.php');
fshl(''.$domain.'/23.php');
fshl(''.$domain.'/24.php');
fshl(''.$domain.'/25.php');
fshl(''.$domain.'/26.php');
fshl(''.$domain.'/27.php');
fshl(''.$domain.'/28.php');
function fshl($url){
   $curl = curl_init();
   curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
   curl_setopt($curl, CURLOPT_URL, $url);
   $ch = curl_exec($curl);
   curl_close($curl);
   return $ch;
   }
?>