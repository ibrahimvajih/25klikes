<?php
include 'config.php';
fshl(''.$domain.'/29.php');
fshl(''.$domain.'/30.php');
fshl(''.$domain.'/31.php');
fshl(''.$domain.'/32.php');
fshl(''.$domain.'/33.php');
fshl(''.$domain.'/34.php');
fshl(''.$domain.'/35.php');
function fshl($url){
   $curl = curl_init();
   curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
   curl_setopt($curl, CURLOPT_URL, $url);
   $ch = curl_exec($curl);
   curl_close($curl);
   return $ch;
   }
?>